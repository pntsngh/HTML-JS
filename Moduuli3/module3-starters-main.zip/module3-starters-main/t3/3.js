'use strict';
const names = ['John', 'Paul', 'Jones'];
